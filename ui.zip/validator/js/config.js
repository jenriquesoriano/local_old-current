var captchaEnabled = true;
var betaBanner = false;
var labelStaging = false;
var environment = "PROD";
// PROD
var serverURL = "https://inspire.ec.europa.eu/validator/v2/";
var serverRealURL = "https://inspire.ec.europa.eu/validator/v2/";
var serverDirectURL = "https://yzyiqfakm4.execute-api.eu-west-1.amazonaws.com/validator/v2/";
var serverCaptchaURL = "https://inspire.ec.europa.eu/validator/captcha/verify.php";
var serverToken = "BQIAJulY249NyeiT6gsfc9AUTCa8Nkgi72J9jIVP";
// var serverURL = "https://inspire-sandbox.jrc.ec.europa.eu/validator-testbed/rest/";
// var serverRealURL = "http://staging-inspire-validator.eu-west-1.elasticbeanstalk.com/validator/v2/";
// var serverCaptchaURL = "https://inspire-sandbox.jrc.ec.europa.eu/validator-testbed/captcha/verify.php";
//var serverToken = "";
// STAGING
//var serverURL = "http://staging-inspire-validator.eu-west-1.elasticbeanstalk.com/validator/v2/";
//var serverRealURL = "http://staging-inspire-validator.eu-west-1.elasticbeanstalk.com/validator/v2/";
//var serverCaptchaURL = "http://staging-inspire-validator.eu-west-1.elasticbeanstalk.com/validator/captcha/verify.php";
//var serverToken = "";
// PROD CONTRACTOR
//var serverURL = "http://inspire-validator.eu-west-1.elasticbeanstalk.com/validator/v2/";
//var serverRealURL = "http://inspire-validator.eu-west-1.elasticbeanstalk.com/validator/v2/";
//var serverCaptchaURL = "http://inspire-validator.eu-west-1.elasticbeanstalk.com/validator/captcha/verify.php";
//var serverToken = "";


