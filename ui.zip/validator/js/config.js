var captchaEnabled = false;
var betaBanner = false;
var labelStaging = false;
// PROD
//var serverURL = "https://inspire-sandbox.jrc.ec.europa.eu/validator-testbed/rest/";
//var serverRealURL = "https://inspire.ec.europa.eu/validator/v2/";
//var serverCaptchaURL = "https://inspire-sandbox.jrc.ec.europa.eu/validator-testbed/captcha/verify.php";
// SANDBOX
// var serverURL = "https://inspire-sandbox.jrc.ec.europa.eu/validator-testbed/rest/";
// var serverRealURL = "http://staging-inspire-validator.eu-west-1.elasticbeanstalk.com/validator/v2/";
// var serverCaptchaURL = "https://inspire-sandbox.jrc.ec.europa.eu/validator-testbed/captcha/verify.php";
// STAGING
//var serverURL = "http://staging-inspire-validator.eu-west-1.elasticbeanstalk.com/validator/v2/";
//var serverRealURL = "http://staging-inspire-validator.eu-west-1.elasticbeanstalk.com/validator/v2/";
//var serverCaptchaURL = "http://staging-inspire-validator.eu-west-1.elasticbeanstalk.com/validator/captcha/verify.php";
// PROD CONTRACTOR
var serverURL = "http://localhost:8090/validator/v2/";
var serverRealURL = "http://localhost:8090/validator/v2/";
var serverCaptchaURL = "http://localhost:8090/validator/v2/validator/captcha/verify.php";
